import 'dotenv/config';

import { db } from '@/db';
import { resources, bookings } from '@/db/schema';
import { user as authUser } from '@/db/auth-schema';

async function seed() {
  console.log('🌱 Starting seed...');

  // Clear existing data (optional - remove if you want to keep existing data)
  await db.delete(bookings);
  await db.delete(resources);
  await db.delete(authUser);

  // Seed Users
  console.log('👤 Seeding users...');
  const users = await db.insert(authUser).values([
    {
      id: 'user_1',
      name: 'John Doe',
      email: 'john@example.com',
      emailVerified: true,
    },
    {
      id: 'user_2',
      name: 'Jane Smith',
      email: 'jane@example.com',
      emailVerified: true,
    },
    {
      id: 'user_3',
      name: 'Bob Johnson',
      email: 'bob@example.com',
      emailVerified: true,
    },
  ]).returning();

  console.log(`✅ ${users.length} users seeded`);

  // Seed Resources
  console.log('🏢 Seeding resources...');
  const resourceData = await db.insert(resources).values([
    {
      name: 'Computer Lab A',
      type: 'lab',
      description: 'High-performance computing lab with 40 workstations',
      capacity: 40,
      location: 'Building 3, Floor 2',
      imageUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400',
    },
    {
      name: 'Main Auditorium',
      type: 'hall',
      description: 'Large auditorium for events and lectures',
      capacity: 200,
      location: 'Building 1, Ground Floor',
      imageUrl: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=400',
    },
    {
      name: 'Projector Set A',
      type: 'equipment',
      description: '4K projector with wireless connectivity',
      capacity: 1,
      location: 'Equipment Room 101',
      imageUrl: 'https://images.unsplash.com/photo-1593642532400-2682810df593?w=400',
    },
    {
      name: 'Physics Lab',
      type: 'lab',
      description: 'Equipped with modern physics instruments',
      capacity: 30,
      location: 'Building 5, Floor 1',
      imageUrl: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=400',
    },
  ]).returning();

  console.log(`✅ ${resourceData.length} resources seeded`);

  // Seed Bookings
  console.log('📅 Seeding bookings...');
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const nextWeek = new Date(now);
  nextWeek.setDate(nextWeek.getDate() + 7);

  const bookingData = await db.insert(bookings).values([
    // Computer Lab A bookings
    {
      resourceId: resourceData[0].id,
      userId: users[0].id,
      startTime: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 9, 0),
      endTime: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 11, 0),
      purpose: 'Programming Class',
      status: 'confirmed',
    },
    {
      resourceId: resourceData[0].id,
      userId: users[1].id,
      startTime: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 14, 0),
      endTime: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 16, 0),
      purpose: 'Data Science Workshop',
      status: 'confirmed',
    },
    // Tomorrow's booking
    {
      resourceId: resourceData[0].id,
      userId: users[2].id,
      startTime: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 10, 0),
      endTime: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 12, 0),
      purpose: 'Web Development Session',
      status: 'pending',
    },
    // Main Auditorium bookings
    {
      resourceId: resourceData[1].id,
      userId: users[0].id,
      startTime: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 13, 0),
      endTime: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 17, 0),
      purpose: 'Annual Tech Conference',
      status: 'confirmed',
    },
    {
      resourceId: resourceData[1].id,
      userId: users[1].id,
      startTime: new Date(nextWeek.getFullYear(), nextWeek.getMonth(), nextWeek.getDate(), 9, 0),
      endTime: new Date(nextWeek.getFullYear(), nextWeek.getMonth(), nextWeek.getDate(), 12, 0),
      purpose: 'Guest Lecture Series',
      status: 'confirmed',
    },
    // Projector bookings
    {
      resourceId: resourceData[2].id,
      userId: users[2].id,
      startTime: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 11, 0),
      endTime: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 13, 0),
      purpose: 'Presentation Setup',
      status: 'confirmed',
    },
    // Physics Lab booking
    {
      resourceId: resourceData[3].id,
      userId: users[1].id,
      startTime: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 8, 0),
      endTime: new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), 10, 0),
      purpose: 'Quantum Mechanics Lab',
      status: 'confirmed',
    },
  ]).returning();

  console.log(`✅ ${bookingData.length} bookings seeded`);
  console.log('🎉 All data seeded successfully!');
  process.exit(0);
}

seed().catch((err) => {
  console.error('❌ Seeding failed:', err);
  process.exit(1);
});