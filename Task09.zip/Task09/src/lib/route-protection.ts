import { redirect } from "next/navigation";
import { getCurrentUser } from "./auth-server";
import { getUserRole, UserRole } from "./rbac";

export interface ProtectedRouteConfig {
  allowedRoles: UserRole[];
  redirectTo?: string;
  isApiRoute?: boolean; // Add this flag
}

export async function protectRoute(config: ProtectedRouteConfig) {
  const user = await getCurrentUser();
  
  if (!user) {
    if (config.isApiRoute) {
      throw new Error("UNAUTHENTICATED");
    }
    redirect(config.redirectTo || "/login");
  }

  const role = await getUserRole(user.id);
  
  if (!role || !config.allowedRoles.includes(role)) {
    if (config.isApiRoute) {
      throw new Error("UNAUTHORIZED");
    }
    redirect("/unauthorized");
  }

  return { user, role };
}

// Add this helper function specifically for API routes
export async function protectApiRoute(allowedRoles: UserRole[]) {
  return protectRoute({
    allowedRoles,
    isApiRoute: true,
  });
}

export const adminRoutes = {
  allowedRoles: ["admin"] as UserRole[],
  redirectTo: "/login",
};

export const userRoutes = {
  allowedRoles: ["user"] as UserRole[],
  redirectTo: "/login",
};

