import { pgTable, text, timestamp, serial, integer, index, boolean } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
import { user as authUser } from './auth-schema';

export const testTable = pgTable('test_table', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .unique()
    .references(() => authUser.id, { onDelete: 'cascade' }),
  role: text('role', { enum: ['admin', 'user'] }).notNull().default('user'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at')
    .defaultNow()
    .$onUpdate(() => new Date())
    .notNull(),
});


// Resources table (labs, halls, equipment)
export const resources = pgTable('resources', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  type: text('type', { enum: ['lab', 'hall', 'equipment'] }).notNull(),
  description: text('description'),
  capacity: integer('capacity'),
  location: text('location'),
  imageUrl: text('image_url'),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at')
    .defaultNow()
    .$onUpdate(() => new Date())
    .notNull(),
});

// Bookings table
export const bookings = pgTable('bookings', {
  id: serial('id').primaryKey(),
  resourceId: integer('resource_id')
    .notNull()
    .references(() => resources.id, { onDelete: 'cascade' }),
  userId: text('user_id')
    .notNull()
    .references(() => authUser.id, { onDelete: 'cascade' }),
  startTime: timestamp('start_time').notNull(),
  endTime: timestamp('end_time').notNull(),
  purpose: text('purpose'),
  status: text('status', { 
    enum: ['pending', 'confirmed', 'cancelled', 'completed'] 
  }).default('confirmed').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at')
    .defaultNow()
    .$onUpdate(() => new Date())
    .notNull(),
}, (table) => [
  index('bookings_resource_id_idx').on(table.resourceId),
  index('bookings_user_id_idx').on(table.userId),
  index('bookings_start_time_idx').on(table.startTime),
]);

// Relations
export const resourceRelations = relations(resources, ({ many }) => ({
  bookings: many(bookings),
}));

export const bookingRelations = relations(bookings, ({ one }) => ({
  resource: one(resources, {
    fields: [bookings.resourceId],
    references: [resources.id],
  }),
  user: one(authUser, {
    fields: [bookings.userId],
    references: [authUser.id],
  }),
}));

export type Resource = typeof resources.$inferSelect;
export type NewResource = typeof resources.$inferInsert;
export type Booking = typeof bookings.$inferSelect;
export type NewBooking = typeof bookings.$inferInsert;

export type ResourceWithBookings = Resource & {
  bookings: Booking[];
};

export type BookingWithUser = Booking & {
  user: {
    id: string;
    name: string;
    email: string;
  };
};