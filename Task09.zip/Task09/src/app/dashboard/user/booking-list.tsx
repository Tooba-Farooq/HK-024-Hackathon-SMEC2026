// app/dashboard/user/bookings-list.tsx
"use client";

import { useEffect, useState } from "react";

interface Booking {
  id: number;
  resourceId: number;
  startTime: string;
  endTime: string;
  purpose: string | null;
  status: string;
  resource: {
    id: number;
    name: string;
    type: string;
    location: string | null;
  };
}

export function BookingsList() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchBookings() {
      try {
        const res = await fetch("/api/user_history");
        
        if (!res.ok) {
          const errorData = await res.json().catch(() => ({}));
          throw new Error(errorData.error || `HTTP ${res.status}: ${res.statusText}`);
        }
        
        const data = await res.json();
        setBookings(data.bookings || []);
      } catch (err) {
        console.error("Fetch error:", err);
        const errorMessage = err instanceof Error ? err.message : "Could not load your booking history.";
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    }

    fetchBookings();
  }, []);

  const formatDateTime = (iso: string) => {
    const date = new Date(iso);
    return date.toLocaleString([], { dateStyle: "short", timeStyle: "short" });
  };

  if (loading) {
    return <p className="text-gray-400">Loading bookings...</p>;
  }

  if (error) {
    return (
      <div className="text-red-400">
        <p className="font-medium">Error loading bookings:</p>
        <p className="text-sm mt-1">{error}</p>
      </div>
    );
  }

  if (bookings.length === 0) {
    return <p className="text-gray-300">You have no bookings yet.</p>;
  }

  return (
    <ul className="space-y-2">
      {bookings.map((b) => (
        <li
          key={b.id}
          className="bg-gray-700 p-3 rounded-lg flex justify-between items-center"
        >
          <div>
            <p className="text-gray-100 font-medium">
              {b.resource.name} ({b.resource.type})
            </p>
            <p className="text-gray-400 text-sm">
              {formatDateTime(b.startTime)} - {formatDateTime(b.endTime)}
            </p>
            <p className="text-gray-400 text-sm">
              Purpose: {b.purpose || "N/A"}
            </p>
          </div>
          <span
            className={`px-2 py-1 rounded-full text-xs font-medium ${
              b.status === "pending"
                ? "bg-yellow-600 text-yellow-100"
                : b.status === "confirmed"
                ? "bg-green-700 text-green-100"
                : b.status === "completed"
                ? "bg-blue-700 text-blue-100"
                : "bg-red-700 text-red-100"
            }`}
          >
            {b.status}
          </span>
        </li>
      ))}
    </ul>
  );
}