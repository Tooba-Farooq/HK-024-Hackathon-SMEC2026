// app/dashboard/user/page.tsx
import Link from "next/link";
import { requireUser } from "@/lib/rbac";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { SignOutButton } from "./sign-out-button";
import { BookingsList } from "./booking-list";

export default async function UserDashboard() {
  const { user, role } = await requireUser();

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-50">User Dashboard</h1>
            <p className="text-gray-400 mt-2">Welcome back, {user.email}</p>
          </div>
          <SignOutButton />
        </div>

        {/* Main Cards Vertical Stack */}
        <div className="flex flex-col gap-6">
          {/* My Profile */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-gray-50">My Profile</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300">
                <span className="font-medium">Email:</span> {user.email}
              </p>
              <p className="text-gray-300">
                <span className="font-medium">User ID:</span> {user.id}
              </p>
            </CardContent>
          </Card>

          {/* My History */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-gray-50">My History</CardTitle>
              <CardDescription className="text-gray-400">
                Track your current and past bookings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <BookingsList />
            </CardContent>
          </Card>

          {/* Resources */}
          <Link href="/resource/user">
            <Card className="bg-gray-800 border-gray-700 cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-gray-50">Resources</CardTitle>
                <CardDescription className="text-gray-400">
                  Browse campus resources
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">
                  View available labs, halls, and equipment to book.
                </p>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  );
}