import { requireAdmin } from "@/lib/rbac";
import Link from 'next/link'; 
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SignOutButton } from "./sign-out-button";

export default async function AdminDashboard() {
  const { user, role } = await requireAdmin();

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-50">
              Admin Dashboard
            </h1>
            <p className="text-gray-400 mt-2">
              Welcome back, {user.email}
            </p>
          </div>
          <SignOutButton />
        </div>

        {/* Main Cards Stack */}
        <div className="flex flex-col gap-6">
          
          {/* View Pending Requests */}
          <Link href="/resource/admin">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-gray-50">Pending Requests</CardTitle>
              <CardDescription className="text-gray-400">
                Check unapproved bookings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300">
                View all pending resource booking requests and take action.
              </p>
            </CardContent>
          </Card>
          </Link>

          {/* View All Bookings */}
          <Link href="/resource/admin">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-gray-50">All Bookings</CardTitle>
              <CardDescription className="text-gray-400">
                Monitor resource usage
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300">
                See all bookings history and status for reporting and monitoring.
              </p>
            </CardContent>
          </Card>
          </Link>
        </div>
      </div>
    </div>
  );
}
