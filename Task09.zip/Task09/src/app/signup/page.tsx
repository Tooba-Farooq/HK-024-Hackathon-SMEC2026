"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { authClient } from "@/lib/auth-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { createUserRoleAction } from "@/serverActions/auth/actions";
import Link from "next/link";

export default function SignupPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState<"admin" | "user">("user");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      setLoading(false);
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      setLoading(false);
      return;
    }

    try {
      const result = await authClient.signUp.email({
        email,
        password,
        name,
      });

      if (result.error) {
        setError(result.error.message || "Sign up failed");
        setLoading(false);
        return;
      }

      if (result.data?.user) {
        // Wait a bit for the session to be established
        await new Promise((resolve) => setTimeout(resolve, 500));

        // Create user with role using server action
        const roleResult = await createUserRoleAction(result.data.user.id, role);

        if (!roleResult.success) {
          setError(roleResult.error || "Failed to set user role");
          setLoading(false);
          return;
        }

        // Wait a bit more before redirecting
        await new Promise((resolve) => setTimeout(resolve, 300));

        // Redirect based on role
        if (role === "admin") {
          router.push("/dashboard/admin");
        } else {
          router.push("/dashboard/user");
        }
      }
    } catch {
      setError("An error occurred. Please try again.");
      setLoading(false);
    }
  };

 return (
  <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-800 p-4">
    <div className="w-full max-w-md animate-in fade-in-0 zoom-in-95 duration-500">
      <Card className="border border-gray-700 shadow-2xl bg-gray-900">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-3xl font-bold text-gray-100">
            Create Account
          </CardTitle>
          <CardDescription className="text-gray-400">
            Sign up to get started
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSignup} className="space-y-4">
            {/* Role */}
            <div className="space-y-2">
              <Label className="text-gray-300">Sign Up As</Label>
              <Tabs value={role} onValueChange={(v) => setRole(v as "admin" | "user")}>
                <TabsList className="grid w-full grid-cols-2 bg-gray-800 border border-gray-700">
                  <TabsTrigger
                    value="user"
                    className="data-[state=active]:bg-gray-700 data-[state=active]:text-white"
                  >
                    User
                  </TabsTrigger>
                  <TabsTrigger
                    value="admin"
                    className="data-[state=active]:bg-gray-700 data-[state=active]:text-white"
                  >
                    Admin
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {/* Name */}
            <div className="space-y-2">
              <Label className="text-gray-300">Name</Label>
              <Input
                type="text"
                placeholder="John Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="h-11 bg-gray-800 border-gray-700 text-gray-100 placeholder:text-gray-500 focus:ring-gray-500"
              />
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label className="text-gray-300">Email</Label>
              <Input
                type="email"
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="h-11 bg-gray-800 border-gray-700 text-gray-100 placeholder:text-gray-500 focus:ring-gray-500"
              />
            </div>

            {/* Password */}
            <div className="space-y-2">
              <Label className="text-gray-300">Password</Label>
              <Input
                type="password"
                placeholder="At least 6 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-11 bg-gray-800 border-gray-700 text-gray-100 placeholder:text-gray-500 focus:ring-gray-500"
              />
            </div>

            {/* Confirm Password */}
            <div className="space-y-2">
              <Label className="text-gray-300">Confirm Password</Label>
              <Input
                type="password"
                placeholder="Confirm your password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className="h-11 bg-gray-800 border-gray-700 text-gray-100 placeholder:text-gray-500 focus:ring-gray-500"
              />
            </div>

            {/* Error */}
            {error && (
              <div className="text-sm text-red-400 bg-red-950/40 p-3 rounded-md border border-red-900">
                {error}
              </div>
            )}

            {/* Submit */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-11 bg-gray-100 text-black hover:bg-gray-300 transition-all duration-200 font-medium"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="animate-spin">⏳</span>
                  Creating account...
                </span>
              ) : (
                "Sign Up"
              )}
            </Button>
          </form>

          {/* Footer */}
          <div className="mt-6 text-center text-sm text-gray-400">
            Already have an account?{" "}
            <Link
              href="/login"
              className="text-gray-200 hover:text-white font-medium underline-offset-4 hover:underline"
            >
              Sign in
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  </div>
);

}

