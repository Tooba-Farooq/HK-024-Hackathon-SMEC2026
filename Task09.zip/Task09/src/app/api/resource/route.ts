// app/api/resource/route.js
import { NextResponse } from 'next/server';
import { db } from '@/db';
import { resources, bookings } from '@/db/schema';
import { eq, gte } from 'drizzle-orm';
import { protectApiRoute, userRoutes } from '@/lib/route-protection'; // Add this import


export async function GET() {
  try {
    // Protect the API route - only allow logged-in users with 'user' or 'admin' role
    const { user, role } = await protectApiRoute(["user"]);
    // OR use directly: await protectApiRoute(['user', 'admin']);
    
    console.log(`API accessed by user: ${user.id} with role: ${role}`);

    const now = new Date();
    
    const data = await db.query.resources.findMany({
      where: eq(resources.isActive, true),
      with: {
        bookings: {
          where: gte(bookings.endTime, now), // Only future/current bookings
          orderBy: (bookings, { asc }) => [asc(bookings.startTime)]
        }
      },
      orderBy: (resources, { asc }) => [asc(resources.name)]
    });

    return NextResponse.json(data);
  } catch (err) {
  // Ensure we can safely access message
  const errorMessage = err instanceof Error ? err.message : String(err);
  console.error('GET /api/resources error:', err);

  if (errorMessage === "UNAUTHENTICATED") {
    return NextResponse.json(
      { error: 'Authentication required. Please log in.' },
      { status: 401 }
    );
  }

  if (errorMessage === "UNAUTHORIZED") {
    return NextResponse.json(
      { error: 'You do not have permission to access this resource.' },
      { status: 403 }
    );
  }

  return NextResponse.json(
    { error: 'Failed to fetch resources' },
    { status: 500 }
  );
}

}