// app/api/resource/book/route.ts
import { NextResponse } from "next/server";
import { db } from "@/db";
import { bookings, resources } from "@/db/schema";
import { eq, and, gte, lte, or } from "drizzle-orm"; // <- add or
import { protectApiRoute } from "@/lib/route-protection";

// POST /api/resource/book
export async function POST(req: Request) {
  try {
    // Only allow logged-in users
    const { user } = await protectApiRoute(["user"]);

    const body = await req.json();
    const { resourceId, startTime, endTime, purpose } = body;

    if (!resourceId || !startTime || !endTime || !purpose) {
      return NextResponse.json(
        { error: "Missing required fields." },
        { status: 400 }
      );
    }

    const start = new Date(startTime);
    const end = new Date(endTime);

    if (isNaN(start.getTime()) || isNaN(end.getTime()) || start >= end) {
      return NextResponse.json(
        { error: "Invalid start or end time." },
        { status: 400 }
      );
    }

    // Check if resource exists and is active
    const resource = await db.query.resources.findFirst({
      where: eq(resources.id, resourceId),
    });

    if (!resource || !resource.isActive) {
      return NextResponse.json(
        { error: "Resource not found or inactive." },
        { status: 404 }
      );
    }

    // Check for booking conflicts
    const conflict = await db.query.bookings.findFirst({
      where: and(
        eq(bookings.resourceId, resourceId),
        eq(bookings.status, "confirmed"),
        or(
          // Existing booking overlaps start
          and(gte(bookings.startTime, start), lte(bookings.startTime, end)),
          // Existing booking overlaps end
          and(gte(bookings.endTime, start), lte(bookings.endTime, end)),
          // Existing booking completely within new booking
          and(lte(bookings.startTime, start), gte(bookings.endTime, end))
        )
      ),
    });

    if (conflict) {
      return NextResponse.json(
        { error: "This time slot is already booked." },
        { status: 409 }
      );
    }

    // Create new booking with status "pending"
    const newBooking = await db.insert(bookings).values({
      resourceId,
      userId: user.id,
      startTime: start,
      endTime: end,
      purpose,
      status: "pending",
    }).returning();

    return NextResponse.json({ booking: newBooking[0] }, { status: 201 });
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    console.error("POST /api/resource/book error:", err);

    if (errorMessage === "UNAUTHENTICATED") {
      return NextResponse.json(
        { error: "Authentication required. Please log in." },
        { status: 401 }
      );
    }

    if (errorMessage === "UNAUTHORIZED") {
      return NextResponse.json(
        { error: "You do not have permission to book resources." },
        { status: 403 }
      );
    }

    return NextResponse.json(
      { error: "Failed to create booking." },
      { status: 500 }
    );
  }
}
