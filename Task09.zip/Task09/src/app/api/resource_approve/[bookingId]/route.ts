// app/api/resource_approve/[bookingId]/route.ts
import { NextResponse } from 'next/server';
import { db } from '@/db';
import { bookings } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { protectApiRoute } from '@/lib/route-protection';

export async function PATCH(
  req: Request,
  context: { params: Promise<{ bookingId: string }> }
) {
  try {
    // Protect route - only admins can access
    await protectApiRoute(['admin']);

    // Await params in Next.js 15+
    const params = await context.params;
    const bookingId = Number(params.bookingId);
    
    console.log('Booking ID from params:', params.bookingId);
    console.log('Parsed booking ID:', bookingId);

    // Validate bookingId
    if (Number.isNaN(bookingId) || bookingId <= 0) {
      return NextResponse.json({ error: 'Invalid booking ID' }, { status: 400 });
    }

    // Parse request body
    const body = await req.json();
    const { status } = body;

    console.log('Status from request:', status);

    // Validate status
    if (!['confirmed', 'cancelled'].includes(status)) {
      return NextResponse.json({ 
        error: 'Invalid status. Must be "confirmed" or "cancelled"' 
      }, { status: 400 });
    }

    // Update booking in database
    const updated = await db
      .update(bookings)
      .set({ 
        status, 
        updatedAt: new Date() 
      })
      .where(eq(bookings.id, bookingId))
      .returning();

    // Check if booking was found and updated
    if (!updated.length) {
      return NextResponse.json({ error: 'Booking not found' }, { status: 404 });
    }

    // Return success response
    return NextResponse.json({
      message: `Booking ${status} successfully`,
      booking: updated[0],
    });

  } catch (err) {
    console.error('Error updating booking:', err);
    
    const message = err instanceof Error ? err.message : String(err);

    // Handle auth errors
    if (message === 'UNAUTHENTICATED') {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    if (message === 'UNAUTHORIZED') {
      return NextResponse.json({ error: 'Admin only' }, { status: 403 });
    }

    // Handle other errors
    return NextResponse.json({ 
      error: 'Failed to update booking',
      details: message 
    }, { status: 500 });
  }
}