// app/api/resource/admin/route.ts
import { NextResponse } from 'next/server';
import { db } from '@/db';
import { resources, bookings } from '@/db/schema';
import { protectApiRoute } from '@/lib/route-protection';

export async function GET() {
  try {
    // Only allow admins
    const { user, role } = await protectApiRoute(['admin']);
    console.log(`Admin API accessed by user: ${user.id} with role: ${role}`);

    // Fetch all resources with their bookings (pending & confirmed)
    const data = await db.query.resources.findMany({
      with: {
        bookings: {
          orderBy: (bookings, { asc }) => [asc(bookings.startTime)],
        },
      },
      orderBy: (resources, { asc }) => [asc(resources.name)],
    });

    return NextResponse.json(data);
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    console.error('GET /api/resource/admin error:', err);

    if (errorMessage === 'UNAUTHENTICATED') {
      return NextResponse.json(
        { error: 'Authentication required. Please log in.' },
        { status: 401 }
      );
    }

    if (errorMessage === 'UNAUTHORIZED') {
      return NextResponse.json(
        { error: 'Admin only: You do not have permission.' },
        { status: 403 }
      );
    }

    return NextResponse.json(
      { error: 'Failed to fetch resources' },
      { status: 500 }
    );
  }
}
