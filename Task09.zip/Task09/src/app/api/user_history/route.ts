// app/api/resource/user-bookings/route.ts
import { NextResponse } from "next/server";
import { db } from "@/db";
import { bookings, resources } from "@/db/schema";
import { eq } from "drizzle-orm";
import { protectApiRoute } from "@/lib/route-protection";

// GET /api/resource/user-bookings
export async function GET() {
  try {
    // Protect the route: only logged-in users
    const { user } = await protectApiRoute(["user"]);

    // Fetch bookings for this user
    const userBookings = await db.query.bookings.findMany({
      where: eq(bookings.userId, user.id),
      orderBy: (b, { asc, desc }) => [desc(b.startTime)],
      with: {
        resource: true, // include resource details
      },
    });

    return NextResponse.json({ bookings: userBookings });
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    console.error("GET /api/resource/user-bookings error:", err);

    if (errorMessage === "UNAUTHENTICATED") {
      return NextResponse.json(
        { error: "Authentication required. Please log in." },
        { status: 401 }
      );
    }

    if (errorMessage === "UNAUTHORIZED") {
      return NextResponse.json(
        { error: "You do not have permission to view bookings." },
        { status: 403 }
      );
    }

    return NextResponse.json(
      { error: "Failed to fetch user bookings." },
      { status: 500 }
    );
  }
}
