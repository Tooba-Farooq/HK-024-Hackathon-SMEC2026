import { protectRoute, userRoutes } from '@/lib/route-protection';
import ResourceCatalog from './component/ResourceCatalog';
import { getUserRole } from '@/lib/rbac';

export default async function ResourcePage() {
  const { user,role } = await protectRoute(userRoutes);



  const currentUser = {
    id: user.id,
    name: user.name || user.email || 'User',
    email: user.email,
    role,  
  };

  return <ResourceCatalog currentUser={currentUser} />;
}
