'use client'
import React, { useEffect, useState } from 'react';
import { Search, MapPin, Users, Clock } from 'lucide-react';
import { SignOutButton } from '@/app/dashboard/user/sign-out-button';

interface ResourceCatalogProps {
  currentUser: {
    id: string;
    name: string;
    email: string;
    role: string;
  };
}

interface Booking {
  id: number;
  resourceId: number;
  userId: string;
  startTime: string;
  endTime: string;
  purpose: string | null;
  status: string;
  createdAt: string;
  updatedAt: string;
}

interface Resource {
  id: number;
  name: string;
  type: string;
  description: string | null;
  capacity: number | null;
  location: string | null;
  imageUrl: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  bookings: Booking[];
}

export default function ResourceCatalog({ currentUser }: ResourceCatalogProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [bookingInProgress, setBookingInProgress] = useState(false);

  useEffect(() => {
    async function fetchResources() {
      try {
        const res = await fetch('/api/resource');

        if (!res.ok) {
          throw new Error('Failed to fetch resources');
        }

        const data = await res.json();
        setResources(data);
      } catch (err) {
        setError('Could not load resources');
        console.error(err);
      } finally {
        setLoading(false);
      }
    }

    fetchResources();
  }, []);

  const filteredResources = resources.filter(resource => {
    const matchesSearch =
      resource.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (resource.description?.toLowerCase().includes(searchTerm.toLowerCase()) ?? false);
    const matchesType = selectedType === 'all' || resource.type === selectedType;
    return matchesSearch && matchesType;
  });

  const getAvailabilityStatus = (resource: Resource): string => {
    const bookings = resource.bookings || [];
    const now = new Date();

    const isCurrentlyBooked = bookings.some(booking => {
      const start = new Date(booking.startTime);
      const end = new Date(booking.endTime);
      return now >= start && now < end && booking.status === 'confirmed';
    });

    return isCurrentlyBooked ? 'Occupied' : 'Available';
  };

  const getBookingsForDate = (resource: Resource, date: string): Booking[] => {
    const bookings = resource.bookings || [];
    const selectedDateObj = new Date(date);

    return bookings.filter(booking => {
      const bookingDate = new Date(booking.startTime);
      return (
        bookingDate.getFullYear() === selectedDateObj.getFullYear() &&
        bookingDate.getMonth() === selectedDateObj.getMonth() &&
        bookingDate.getDate() === selectedDateObj.getDate()
      );
    });
  };

  const isTimeSlotInPast = (hour: number, date: string): boolean => {
    const now = new Date();
    const slotDate = new Date(date);
    slotDate.setHours(hour, 0, 0, 0);

    return slotDate < now;
  };

  const isToday = (date: string): boolean => {
    const today = new Date();
    const selectedDateObj = new Date(date);

    return (
      today.getFullYear() === selectedDateObj.getFullYear() &&
      today.getMonth() === selectedDateObj.getMonth() &&
      today.getDate() === selectedDateObj.getDate()
    );
  };

  const bookSlot = async (hour: number) => {
    if (!selectedResource || bookingInProgress) return;

    const startTime = new Date(selectedDate);
    startTime.setHours(hour, 0, 0, 0);

    const endTime = new Date(selectedDate);
    endTime.setHours(hour + 1, 0, 0, 0);

    setBookingInProgress(true);

    try {
      const res = await fetch('/api/resource_req', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resourceId: selectedResource.id,
          startTime: startTime.toISOString(),
          endTime: endTime.toISOString(),
          purpose: `Booked by ${currentUser.name}`,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'Failed to book slot');
        return;
      }

      alert('Slot booked successfully! Status: pending');

      // Update local state
      setResources(prev =>
        prev.map(r =>
          r.id === selectedResource.id
            ? { ...r, bookings: [...r.bookings, data.booking] }
            : r
        )
      );

      // Update selected resource to reflect the change
      setSelectedResource(prev => 
        prev ? { ...prev, bookings: [...prev.bookings, data.booking] } : null
      );
    } catch (err) {
      console.error(err);
      alert('Something went wrong while booking the slot.');
    } finally {
      setBookingInProgress(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 p-6">
        <div className="text-center py-10 text-gray-400">Loading resources...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 p-6">
        <div className="text-center py-10 text-red-400">{error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 p-6 text-gray-100">
      <div className="max-w-7xl mx-auto">
        
        <div className="w-full flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-gray-100">Resources</h1>
          <SignOutButton />
        </div>

        {/* Search and Filters */}
        <div className="bg-gray-800 rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search resources..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-700 rounded-lg bg-gray-900 text-gray-100 focus:ring-2 focus:ring-gray-500 focus:border-transparent"
              />
            </div>
            <select
              value={selectedType}
              onChange={e => setSelectedType(e.target.value)}
              className="px-4 py-2 border border-gray-700 rounded-lg bg-gray-900 text-gray-100 focus:ring-2 focus:ring-gray-500 focus:border-transparent"
            >
              <option value="all">All Types</option>
              <option value="lab">Labs</option>
              <option value="hall">Halls</option>
              <option value="equipment">Equipment</option>
            </select>
          </div>
        </div>

        {/* Resources Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          {filteredResources.map(resource => (
            <div
              key={resource.id}
              onClick={() => setSelectedResource(resource)}
              className="bg-gray-800 rounded-lg shadow-sm overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
            >
              <img
                src={resource.imageUrl || '/placeholder-image.jpg'}
                alt={resource.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-lg font-semibold text-gray-100">{resource.name}</h3>
                  <span
                    className={`px-2 py-1 text-xs rounded-full ${
                      getAvailabilityStatus(resource) === 'Available'
                        ? 'bg-green-700 text-green-200'
                        : 'bg-red-700 text-red-200'
                    }`}
                  >
                    {getAvailabilityStatus(resource)}
                  </span>
                </div>
                <p className="text-sm text-gray-400 mb-3">{resource.description}</p>
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    <span>{resource.location || 'N/A'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    <span>{resource.capacity || 'N/A'}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Calendar Modal */}
        {selectedResource && (
          <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50">
            <div className="bg-gray-800 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto text-gray-100">
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h2 className="text-2xl font-bold">{selectedResource.name}</h2>
                    <p className="text-gray-400">{selectedResource.location || 'No location'}</p>
                  </div>
                  <button
                    onClick={() => setSelectedResource(null)}
                    className="text-gray-400 hover:text-gray-200 text-2xl"
                  >
                    ✕
                  </button>
                </div>

                {/* Date Selector */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Select Date
                  </label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={e => setSelectedDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-gray-900 text-gray-100 focus:ring-2 focus:ring-gray-500"
                  />
                </div>

                {/* Time Slots */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Availability for {selectedDate}</h3>
                  <div className="space-y-2">
                    {[8, 9, 10, 11, 12, 13, 14, 15, 16, 17].map(hour => {
                      const bookingsForDate = getBookingsForDate(selectedResource, selectedDate);
                      const booking = bookingsForDate.find(b => {
                        const start = new Date(b.startTime).getHours();
                        const end = new Date(b.endTime).getHours();
                        return hour >= start && hour < end;
                      });

                      const isPast = isToday(selectedDate) && isTimeSlotInPast(hour, selectedDate);

                      if (isPast && !booking) return null;

                      return (
                        <div
                          key={hour}
                          className={`p-3 rounded-lg flex items-center justify-between ${
                            isPast
                              ? 'bg-gray-700 border border-gray-600 opacity-60'
                              : booking
                              ? 'bg-red-900 border border-red-800'
                              : 'bg-green-900 border border-green-800'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Clock className="w-5 h-5 text-gray-400" />
                            <span className="font-medium">{`${hour
                              .toString()
                              .padStart(2, '0')}:00 - ${(hour + 1)
                              .toString()
                              .padStart(2, '0')}:00`}</span>
                          </div>
                          {isPast ? (
                            <span className="text-sm text-gray-400">
                              {booking ? `${booking.purpose || 'Booked'} (Past)` : 'Past'}
                            </span>
                          ) : booking ? (
                            <div className="text-right">
                              <span className="text-sm text-red-300 block">{booking.purpose || 'Booked'}</span>
                              <span className="text-xs text-gray-400">Status: {booking.status}</span>
                            </div>
                          ) : (
                            <button
                              className="px-4 py-1 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
                              onClick={() => bookSlot(hour)}
                              disabled={bookingInProgress}
                            >
                              {bookingInProgress ? 'Booking...' : 'Book'}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}