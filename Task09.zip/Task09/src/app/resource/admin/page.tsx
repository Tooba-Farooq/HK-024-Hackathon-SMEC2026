import { protectRoute } from '@/lib/route-protection';
import ResourceAdminPanel from './component/ResourceAdmin';
import { getUserRole } from '@/lib/rbac';

export default async function AdminResourcePage() {
  // Only admin can access
  const { user } = await protectRoute({ allowedRoles: ['admin'], redirectTo: '/unauthorized' });

  const role = await getUserRole(user.id);

  const currentUser = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: role!,  
  };

  return <ResourceAdminPanel currentUser={currentUser} />;
}
